
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>  
    <script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:1437661769,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok3v=1613a3a185/"},atok:"3f47cabceb1574fd6a090bfa816e9e85",petok:"56eb109dc09fc52a0e66a641e9cefc508b964755-1438435523-1800",betok:"6104083783788e4bc86ec0be50c332a5a41ede60-1438435523-120",zone:"template-help.com",rocket:"0",apps:{"abetterbrowser":{"ie":"7"},"ga_key":{"ua":"UA-7078796-5","ga_bs":"2"}}}];!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="//ajax.cloudflare.com/cdn-cgi/nexp/dok3v=900caa028b/cloudflare.min.js",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>
<script type="text/javascript">var NREUMQ=NREUMQ||[];NREUMQ.push(["mark","firstbyte",new Date().getTime()]);</script><base href="http://livedemo00.template-help.com/joomla_47434/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>Home</title>
  <link href="http://livedemo00.template-help.com/joomla_47434/" rel="canonical" />
  <link href="/joomla_47434/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/joomla_47434/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="/joomla_47434/templates/theme1694/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <link rel="stylesheet" href="/joomla_47434/templates/theme1694/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="/joomla_47434/templates/theme1694/css/default.css" type="text/css" />
  <link rel="stylesheet" href="/joomla_47434/templates/theme1694/css/template.css" type="text/css" />
  <link rel="stylesheet" href="/joomla_47434/templates/theme1694/css/touch.gallery.css" type="text/css" />
  <link rel="stylesheet" href="/joomla_47434/templates/theme1694/css/responsive.css" type="text/css" />
  <link rel="stylesheet" href="/joomla_47434/templates/theme1694/css/komento.css" type="text/css" />
  <link rel="stylesheet" href="http://livedemo00.template-help.com/joomla_47434/templates/theme1694/css/camera.css" type="text/css" />
  <link rel="stylesheet" href="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/css/superfish.css" type="text/css" />
  <link rel="stylesheet" href="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/css/superfish-navbar.css" type="text/css" />
  <link rel="stylesheet" href="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/css/superfish-vertical.css" type="text/css" />
  <script src="/joomla_47434/media/system/js/mootools-core.js" type="text/javascript"></script>
  <script src="/joomla_47434/media/system/js/core.js" type="text/javascript"></script>
  <script src="/joomla_47434/media/system/js/caption.js" type="text/javascript"></script>
  <script src="/joomla_47434/media/system/js/mootools-more.js" type="text/javascript"></script>
  <script src="/joomla_47434/media/jui/js/jquery.min.js" type="text/javascript"></script>
  <script src="/joomla_47434/templates/theme1694/js/jquery.mobile.customized.min.js" type="text/javascript"></script>
  <script src="/joomla_47434/templates/theme1694/js/jquery.easing.1.3.js" type="text/javascript"></script>
  <script src="/joomla_47434/media/jui/js/bootstrap.js" type="text/javascript"></script>
  <script src="/joomla_47434/templates/theme1694/js/jquery.isotope.min.js" type="text/javascript"></script>
  <script src="/joomla_47434/templates/theme1694/js/touch.gallery.js" type="text/javascript"></script>
  <script src="/joomla_47434/templates/theme1694/js/scripts.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_image_swoop/js/camera.min.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_image_swoop/js/jquery.mobile.customized.min.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_image_swoop/js/jquery.easing.1.3.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/js/superfish.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/js/jquery.mobilemenu.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/js/jquery.hoverIntent.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/js/supersubs.js" type="text/javascript"></script>
  <script src="http://livedemo00.template-help.com/joomla_47434/modules/mod_superfish_menu/js/sftouchscreen.js" type="text/javascript"></script>
  <script type="text/javascript">
window.addEvent('load', function() {
				new JCaption('img.caption');
			});window.addEvent('domready', function() {
			$$('.hasTip').each(function(el) {
				var title = el.get('title');
				if (title) {
					var parts = title.split('::', 2);
					el.store('tip:title', parts[0]);
					el.store('tip:text', parts[1]);
				}
			});
			var JTooltips = new Tips($$('.hasTip'), {"maxTitleChars": 50,"fixed": false});
		});jQuery.noConflict()
  </script>

  <link href='//fonts.googleapis.com/css?family=Courgette' rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Abril+Fatface' rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>

  <!--[if IE 8]>
    <link rel="stylesheet" href="/joomla_47434/templates/theme1694/css/ie.css" />
  <![endif]-->
  
<script type="text/javascript">
/* <![CDATA[ */
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-7078796-5']);
_gaq.push(['_trackPageview']);

(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

(function(b){(function(a){"__CF"in b&&"DJS"in b.__CF?b.__CF.DJS.push(a):"addEventListener"in b?b.addEventListener("load",a,!1):b.attachEvent("onload",a)})(function(){"FB"in b&&"Event"in FB&&"subscribe"in FB.Event&&(FB.Event.subscribe("edge.create",function(a){_gaq.push(["_trackSocial","facebook","like",a])}),FB.Event.subscribe("edge.remove",function(a){_gaq.push(["_trackSocial","facebook","unlike",a])}),FB.Event.subscribe("message.send",function(a){_gaq.push(["_trackSocial","facebook","send",a])}));"twttr"in b&&"events"in twttr&&"bind"in twttr.events&&twttr.events.bind("tweet",function(a){if(a){var b;if(a.target&&a.target.nodeName=="IFRAME")a:{if(a=a.target.src){a=a.split("#")[0].match(/[^?=&]+=([^&]*)?/g);b=0;for(var c;c=a[b];++b)if(c.indexOf("url")===0){b=unescape(c.split("=")[1]);break a}}b=void 0}_gaq.push(["_trackSocial","twitter","tweet",b])}})})})(window);
/* ]]> */
</script>
</head>

<body class="com_content view-category task- itemid-101 body__home">

  <!-- Body -->
  <div id="wrapper">
    <div class="wrapper-inner">

    <!-- Top -->
    
<div class="top_container">
    <!-- Header -->
      <div id="header-row">
        <div class="row-container">
          <div class="container">
            <header>
              <div class="row">
                  <!-- Logo -->
                  <div id="logo" class="span12">
                    <a href="/joomla_47434">
                      <img src="http://livedemo00.template-help.com/joomla_47434/images/logo.png" alt="The Game" />
                    </a>
                  </div>
                  
              </div>
            </header>
          </div>
        </div>
      </div>

    <!-- Navigation -->
          <div id="navigation-row">
        <div class="row-container">
          <div class="container">
            <div class="row">
              <nav>
                <div class="moduletable navigation  span12">
<ul class="sf-menu menu_1 ">

<li class="item-101 current active"><a href="/joomla_47434/" >Home</a></li><li class="item-167 deeper parent"><a href="/joomla_47434/index.php/about" >About</a><ul><li class="item-172"><a href="/joomla_47434/index.php/about/history" >History</a></li><li class="item-170 deeper parent"><a href="/joomla_47434/index.php/about/team" >Team</a><ul><li class="item-171"><a href="/joomla_47434/index.php/about/team/testimonials" >Testimonials</a></li></ul></li><li class="item-168"><a href="/joomla_47434/index.php/about/faqs" >FAQs</a></li></ul></li><li class="item-169"><a href="/joomla_47434/index.php/gallery" >gallery</a></li><li class="item-109"><a href="/joomla_47434/index.php/news" >News</a></li><li class="item-102"><a href="/joomla_47434/index.php/contacts" >Contacts</a></li></ul>

<script type="text/javascript">
	// initialise plugins
	jQuery(function(){
		jQuery('ul.sf-menu')
			 
		.superfish({
			hoverClass:    'sfHover',         
	    pathClass:     'overideThisToUse',
	    pathLevels:    1,    
	    delay:         500, 
	    animation:     {opacity:'show', height:'show'}, 
	    speed:         'normal',   
	    speedOut:      'fast',   
	    autoArrows:    false, 
	    disableHI:     false, 
	    useClick:      0,
	    easing:        "swing",
	    onInit:        function(){},
	    onBeforeShow:  function(){},
	    onShow:        function(){},
	    onHide:        function(){},
	    onIdle:        function(){}
		});
	});

	jQuery(function(){
		jQuery('.sf-menu').mobileMenu({
			defaultText: 'Navigate to...',
			className: 'select-menu',
			subMenuClass: 'sub-menu_1'
		});
	})

	jQuery(function(){
		var ismobile = navigator.userAgent.match(/(iPhone)|(iPod)|(android)|(webOS)/i)
		if(ismobile){
			jQuery('.sf-menu').sftouchscreen({});
		}
	})
</script></div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    
    <!-- Showcase -->
          <div id="showcase-row">
        <div class="moduletable ">

<div id="camera-slideshow" class="  camera_wrap pattern_1">

<div class="camera-item" data-src="/joomla_47434/images/slider/slide-1.jpg" data-thumb="http://livedemo00.template-help.com/joomla_47434/" data-link="" data-target="_self">

			<div class="camera_caption fadeIn">

							
				<h2 class="slide-title">
									Great place  to learn about chess!								</h2>
	
				
				
				
							
		<!-- Read More link -->
		
		</div>
	
</div>

<div class="camera-item" data-src="/joomla_47434/images/slider/slide-2.jpg" data-thumb="http://livedemo00.template-help.com/joomla_47434/" data-link="" data-target="_self">

			<div class="camera_caption fadeIn">

							
				<h2 class="slide-title">
									Nulladuice feugiat  malesuada odiopolo.								</h2>
	
				
				
				
							
		<!-- Read More link -->
		
		</div>
	
</div>

<div class="camera-item" data-src="/joomla_47434/images/slider/slide-3.jpg" data-thumb="http://livedemo00.template-help.com/joomla_47434/" data-link="" data-target="_self">

			<div class="camera_caption fadeIn">

							
				<h2 class="slide-title">
									Lorem ipsum dolor sit amet, Consec tetuer adipicing it. Praesebul.								</h2>
	
				
				
				
							
		<!-- Read More link -->
		
		</div>
	
</div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#camera-slideshow').camera({
			alignment			: "topCenter", //topLeft, topCenter, topRight, centerLeft, center, centerRight, bottomLeft, bottomCenter, bottomRight
			autoAdvance				: true,	//true, false
			mobileAutoAdvance	: true, //true, false. Auto-advancing for mobile devices

			barDirection			: "leftToRight",	//'leftToRight', 'rightToLeft', 'topToBottom', 'bottomToTop'
			barPosition				: "bottom",	//'bottom', 'left', 'top', 'right'
			cols							: 6,
			easing						: "swing",	//for the complete list http://jqueryui.com/demos/effect/easing.html
			mobileEasing			: "swing",	//leave empty if you want to display the same easing on mobile devices and on desktop etc.
			fx								: "simpleFade",	
			mobileFx					: "simpleFade",		//leave empty if you want to display the same effect on mobile devices and on desktop etc.
			gridDifference		: 250,	//to make the grid blocks slower than the slices, this value must be smaller than transPeriod
			height						: "51.829268292682926829268292682927%",	//here you can type pixels (for instance '300px'), a percentage (relative to the width of the slideshow, for instance '50%') or 'auto'
			// imagePath					: 'images/',	//the path to the image folder (it serves for the blank.gif, when you want to display videos)
			hover							: false,	//true, false. Puase on state hover. Not available for mobile devices
			loader						: "none",	//pie, bar, none (even if you choose "pie", old browsers like IE8- can't display it... they will display always a loading bar)
			loaderColor				: "#eeeeee", 
			loaderBgColor			: "#222222", 
			loaderOpacity			: .8,	//0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1
			loaderPadding			: 2,	//how many empty pixels you want to display between the loader and its background
			loaderStroke			: 7,	//the thickness both of the pie loader and of the bar loader. Remember: for the pie, the loader thickness must be less than a half of the pie diameter
			minHeight					: "100px",	//you can also leave it blank
			navigation				: false,	//true or false, to display or not the navigation buttons
			navigationHover		: false,	//if true the navigation button (prev, next and play/stop buttons) will be visible on hover state only, if false they will be 	visible always
			mobileNavHover		: false,	//same as above, but only for mobile devices
			opacityOnGrid			: false,	//true, false. Decide to apply a fade effect to blocks and slices: if your slideshow is fullscreen or simply big, I recommend to set it false to have a smoother effect 
			overlayer					: false,	//a layer on the images to prevent the users grab them simply by clicking the right button of their mouse (.camera_overlayer)
			pagination				: false,
			playPause					: false,	//true or false, to display or not the play/pause buttons
			pauseOnClick			: false,	//true, false. It stops the slideshow when you click the sliders.
			pieDiameter				: 38,
			piePosition				: "rightTop",	//'rightTop', 'leftTop', 'leftBottom', 'rightBottom'
			portrait					: false, //true, false. Select true if you don't want that your images are cropped
			rows							: 4,
			slicedCols				: 6,	//if 0 the same value of cols
			slicedRows				: 4,	//if 0 the same value of rows
			// slideOn				: "",	//next, prev, random: decide if the transition effect will be applied to the current (prev) or the next slide
			thumbnails				: false,
			time							: 7000,	//milliseconds between the end of the sliding effect and the start of the nex one
			transPeriod				: 1500	//lenght of the sliding effect in milliseconds
			// onEndTransition		: function() {  },	//this callback is invoked when the transition effect ends
			// onLoaded					: function() {  },	//this callback is invoked when the image on a slide has completely loaded
			// onStartLoading		: function() {  },	//this callback is invoked when the image on a slide start loading
			// onStartTransition	: function() {  }	//this callback is invoked when the transition effect starts
		});
	});
</script>
</div>
      </div>
        </div>

    <!-- Feature -->
          <div id="feature-row">
        <div class="row-container">
          <div class="container">
            <div class="row">
                <div class="moduletable top_block  span12">
<div class="mod-newsflash-adv mod-newsflash-adv__top_block">

    
    
      <div class="row">
  
    
      <div class="span3 item item_num0 item__module  ">
        
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h1 class="item_title item_title__top_block">
					<span class="item_title_part0">Why</span> <span class="item_title_part1">us?</span> 				</h1>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>Consec tetuer adipicing it. Praesebul.</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>      </div>

    
      <div class="span3 item item_num1 item__module  ">
        
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h1 class="item_title item_title__top_block">
					<span class="item_title_part0">Who</span> <span class="item_title_part1">we</span> <span class="item_title_part2">are?</span> 				</h1>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>S natoque penatibus et gnis dent mo.</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>      </div>

    
      <div class="span3 item item_num2 item__module  ">
        
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h1 class="item_title item_title__top_block">
					<span class="item_title_part0">What</span> <span class="item_title_part1">we</span> <span class="item_title_part2">do?</span> 				</h1>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>Atessetuidiculu. Nulladuice feugiat.</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>      </div>

    
      <div class="span3 item item_num3 item__module  lastItem">
        
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h1 class="item_title item_title__top_block">
					<span class="item_title_part0">Tournaments</span> 				</h1>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>Atessetuidiculu. Nulladuice feugiat.</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>      </div>

    
      </div> 
  
  <div class="clearfix"></div>

  
</div>
</div><div class="moduletable top_blocks  span12">
<div class="mod-newsflash-adv mod-newsflash-adv__top_blocks">

    
    
      <div class="row">
  
    
      <div class="span3 item item_num0 item__module  ">
        
<!-- Intro Image -->
				<div class="item_img img-intro img-intro__none"> 
			<a href="/joomla_47434/index.php/27-carousel/20-lorem-ipsum-dolor-sit-amet">
			<img
						src="/joomla_47434/images/home/home-1.jpg" alt=""/></a> 
		</div>
	
<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__top_blocks">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><span class="black">Consec tetuer adipicing it. Praesebul.</span>
<p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat malesuada odiopolo. Morbnc odiof, gravida at, cursus na loruodem.</p>
</div>

	<!-- Read More link -->
	<a class="btn btn-info readmore" href="/joomla_47434/index.php/27-carousel/20-lorem-ipsum-dolor-sit-amet"><span>more</span></a></div>

<div class="clearfix"></div>      </div>

    
      <div class="span3 item item_num1 item__module  ">
        
<!-- Intro Image -->
				<div class="item_img img-intro img-intro__none"> 
			<a href="/joomla_47434/index.php/27-carousel/21-lorem-ipsum-dolor-sit-amet-2">
			<img
						src="/joomla_47434/images/home/home-2.jpg" alt=""/></a> 
		</div>
	
<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__top_blocks">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><span class="black">Consec tetuer adipicing it. Praesebul.</span>
<p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat malesuada odiopolo. Morbnc odiof, gravida at, cursus na loruodem.</p>
</div>

	<!-- Read More link -->
	<a class="btn btn-info readmore" href="/joomla_47434/index.php/27-carousel/21-lorem-ipsum-dolor-sit-amet-2"><span>more</span></a></div>

<div class="clearfix"></div>      </div>

    
      <div class="span3 item item_num2 item__module  ">
        
<!-- Intro Image -->
				<div class="item_img img-intro img-intro__none"> 
			<a href="/joomla_47434/index.php/27-carousel/22-lorem-ipsum-dolor-sit-amet-3">
			<img
						src="/joomla_47434/images/home/home-3.jpg" alt=""/></a> 
		</div>
	
<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__top_blocks">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><span class="black">Consec tetuer adipicing it. Praesebul.</span>
<p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat malesuada odiopolo. Morbnc odiof, gravida at, cursus na loruodem.</p>
</div>

	<!-- Read More link -->
	<a class="btn btn-info readmore" href="/joomla_47434/index.php/27-carousel/22-lorem-ipsum-dolor-sit-amet-3"><span>more</span></a></div>

<div class="clearfix"></div>      </div>

    
      <div class="span3 item item_num3 item__module  lastItem">
        
<!-- Intro Image -->
				<div class="item_img img-intro img-intro__none"> 
			<a href="/joomla_47434/index.php/27-carousel/23-lorem-ipsum-dolor-sit-amet-4">
			<img
						src="/joomla_47434/images/home/home-4.jpg" alt=""/></a> 
		</div>
	
<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__top_blocks">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><span class="black">Consec tetuer adipicing it. Praesebul.</span>
<p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat malesuada odiopolo. Morbnc odiof, gravida at, cursus na loruodem.</p>
</div>

	<!-- Read More link -->
	<a class="btn btn-info readmore" href="/joomla_47434/index.php/27-carousel/23-lorem-ipsum-dolor-sit-amet-4"><span>more</span></a></div>

<div class="clearfix"></div>      </div>

    
      </div> 
  
  <div class="clearfix"></div>

  
</div>
</div>
            </div>
          </div>
        </div>
      </div>
    

    <!-- Maintop -->
    
    <!-- Main Content row -->
    <div id="content-row">
      <div class="row-container">
        <div class="container">
          <div class="content-inner row">
        
            <!-- Left sidebar -->
                          <div id="aside-left" class="span3">
                <aside>
                  <div class="moduletable services"><h3 class="moduleTitle ">Services</h3><div class="mod-newsflash-adv mod-newsflash-adv__services">

    

  
    <div class="item item_num0 item__module ">
      
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__services">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>    </div>
  
    <div class="item item_num1 item__module ">
      
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__services">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>    </div>
  
    <div class="item item_num2 item__module ">
      
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__services">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>    </div>
  
    <div class="item item_num3 item__module lastItem">
      
<!-- Intro Image -->

<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__services">
					<span class="item_title_part0">Lorem</span> <span class="item_title_part1">ipsum</span> <span class="item_title_part2">dolor</span> <span class="item_title_part3">sit</span> <span class="item_title_part4">amet,</span> 				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>    </div>
  
  <div class="clearfix"></div>

     
    <div class="mod-newsflash-adv_custom-link">
      <a class="btn btn-info" href="/joomla_47434/index.php/services">more</a>    </div>
  </div>
</div>
                </aside>
              </div>
                    
            <div id="component" class="span6">
              <!-- Breadcrumbs -->
                      
              <!-- Content-top -->
                      
                
<div id="system-message-container">
<div id="system-message">
</div>
</div>
                <div class="page-category page-category__home">

		<div class="page_header">
		<h3><span class="item_title_part0">About</span> <span class="item_title_part1">us</span> </h3>	</div>
	
	
	
		

						<div class="items-row cols-1 row-0 row-fluid">
					<div class="span12">
				<div class="item column-1">
					
<!-- Icons -->
	
<!-- Intro image -->
		

<!--  title/author -->
			<div class="item_header">
					<h4 class="item_title">									<a href="/joomla_47434/index.php/1-home-morbi-tincidunt-sodales-neque-eu-rutrum"> <span class="item_title_part0">reprehenderit</span> <span class="item_title_part1">qui</span> <span class="item_title_part2">in</span> <span class="item_title_part3">ea</span> <span class="item_title_part4">voluptate</span> <span class="item_title_part5">velit</span> <span class="item_title_part6">esse</span> <span class="item_title_part7">quam</span> <span class="item_title_part8">nihil</span> </a>
							</h4>		
		
				</div>
	
	
<!-- info TOP -->
			
			
<!-- Introtext -->
	<div class="item_introtext">		<div class="moduletable team">
					
<div class="mod-newsflash-adv mod-newsflash-adv__ team">

    

    
      <div class="span6 item item_num0 item__module  ">
        
<!-- Intro Image -->
				<div class="item_img img-intro img-intro__none"> 
			<a href="/joomla_47434/index.php/about/team/48-john-sommersmith">
			<img
						src="/joomla_47434/images/team/team-1.jpg" alt=""/></a> 
		</div>
	
<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__ team">
					<a href="/joomla_47434/index.php/about/team/48-john-sommersmith">
				John sommersmith</a>
				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>Loremip ipsum dolor sit amet, consec.</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>      </div>

    
      <div class="span6 item item_num1 item__module  lastItem">
        
<!-- Intro Image -->
				<div class="item_img img-intro img-intro__none"> 
			<a href="/joomla_47434/index.php/about/team/49-tom-simpson">
			<img
						src="/joomla_47434/images/team/team-2.jpg" alt=""/></a> 
		</div>
	
<div class="item_content">

		<!-- Item title -->
			<h4 class="item_title item_title__ team">
					<a href="/joomla_47434/index.php/about/team/49-tom-simpson">
				Tom simpson</a>
				</h4>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>Loremip ipsum dolor sit amet, consec.</p>
</div>

	<!-- Read More link -->
	</div>

<div class="clearfix"></div>      </div>

    
  <div class="clearfix"></div>

  
</div>
		</div>
	
<span class="black">Consec tetuer adipicing it. Praesebul natoque penatibus et gnis dent mo ntessetuidiculu. Nul laduice feugiat  malesuada odiopolo. Morbnc odiof,  gravida at, cursus na loruodem.</span> 
<p>Loremip ipsum dolor sit amet, consec tetuer ng elit. Praesent vestibulummolestie lacus. Aenean non ummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mium sociis natoque penati.</p>
</div>

<!-- info BOTTOM -->
	
<!-- More -->
			<a class="btn btn-info" href="/joomla_47434/index.php/1-home-morbi-tincidunt-sodales-neque-eu-rutrum"><span>
		More		</span></a>
	
				</div><!-- end item -->
							</div><!-- end spann -->
						
		</div><!-- end row -->
						
	

		</div>

        
              <!-- Content-bottom -->
                          </div>
        
            <!-- Right sidebar -->
                          <div id="aside-right" class="span3">
                <aside>
                  <div class="moduletable news"><h3 class="moduleTitle ">Latest news</h3><div class="mod-newsflash-adv mod-newsflash-adv__news">

    

  
    <div class="item item_num0 item__module ">
      
<!-- Intro Image -->

<div class="item_content">

			<div class="item_published">
			25.09.2012		</div>
		<!-- Item title -->
			<h6 class="item_title item_title__news">
					<a href="/joomla_47434/index.php/38-latest-news/73-s-natoque-penatibus-et-gnis-dent-mo-ntessetuidiculu-nulladuice-feugiat">
				S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat</a>
				</h6>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>malesuada odiopolo. Morbnc odiof, gravida at, cursus na loruodem.</p>
</div>

	<!-- Read More link -->
	<a class="btn btn-info readmore" href="/joomla_47434/index.php/38-latest-news/73-s-natoque-penatibus-et-gnis-dent-mo-ntessetuidiculu-nulladuice-feugiat"><span>more</span></a></div>

<div class="clearfix"></div>    </div>
  
    <div class="item item_num1 item__module ">
      
<!-- Intro Image -->

<div class="item_content">

			<div class="item_published">
			25.09.2012		</div>
		<!-- Item title -->
			<h6 class="item_title item_title__news">
					<a href="/joomla_47434/index.php/38-latest-news/74-s-natoque-penatibus-et-gnis-dent-mo-ntessetuidiculu-nulladuice-feugiat-2">
				S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat</a>
				</h6>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>malesuada odiopolo. Morbnc odiof, gravida at, cursus na loruodem.</p>
</div>

	<!-- Read More link -->
	<a class="btn btn-info readmore" href="/joomla_47434/index.php/38-latest-news/74-s-natoque-penatibus-et-gnis-dent-mo-ntessetuidiculu-nulladuice-feugiat-2"><span>more</span></a></div>

<div class="clearfix"></div>    </div>
  
    <div class="item item_num2 item__module lastItem">
      
<!-- Intro Image -->

<div class="item_content">

			<div class="item_published">
			25.09.2012		</div>
		<!-- Item title -->
			<h6 class="item_title item_title__news">
					<a href="/joomla_47434/index.php/38-latest-news/75-s-natoque-penatibus-et-gnis-dent-mo-ntessetuidiculu-nulladuice-feugiat-3">
				S natoque penatibus et gnis dent mo ntessetuidiculu. Nulladuice feugiat</a>
				</h6>
	
	
	
	
	
	<!-- Introtext -->
	<div class="item_introtext"><p>malesuada odiopolo. Morbnc odiof, gravida at, cursus na loruodem.</p>
</div>

	<!-- Read More link -->
	<a class="btn btn-info readmore" href="/joomla_47434/index.php/38-latest-news/75-s-natoque-penatibus-et-gnis-dent-mo-ntessetuidiculu-nulladuice-feugiat-3"><span>more</span></a></div>

<div class="clearfix"></div>    </div>
  
  <div class="clearfix"></div>

  </div>
</div>
                </aside>
              </div>
                      </div>
        </div>
      </div>
    </div>

    <!-- Mainbottom -->
    
    <!-- Bottom -->
        <div id="push"></div>
    </div>
  </div>

  <div id="footer-wrapper">
    <div class="footer-wrapper-inner">
      <!-- Footer -->
            
      <!-- Copyright -->
        <div id="copyright-row">
          <div class="row-container">
            <div class="container">
              <div class="row">
                <div class="moduletable   span12">
<div class="mod-menu__social">
	<ul class="menu social">
	<li class="item-146"><a class="facebook" href="#" >Facebook</a></li><li class="item-148"><a class="twitter" href="#" >Twitter</a></li><li class="item-147"><a class="feed" href="#" >Feed</a></li></ul>
</div>
</div>
                  <!-- Logo -->
                  <div id="copyright" class="span12">
					<span class="year">2015</span>          <span class="copy">&copy;</span>                                        <a class="privacy_link" href="/joomla_47434/index.php/privacy-policy">Privacy Policy</a>
  					                                      </div>
                <!-- {%FOOTER_LINK} -->
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>
      <div id="back-top">
      <a href="#"><span></span> </a>
    </div>
  

  
  

  <script type="text/javascript">/* CloudFlare analytics upgrade */
</script>
<script type="text/javascript">if(!NREUMQ.f){NREUMQ.f=function(){NREUMQ.push(["load",new Date().getTime()]);var e=document.createElement("script");e.type="text/javascript";e.src=(("http:"===document.location.protocol)?"http:":"https:")+"//"+"js-agent.newrelic.com/nr-100.js";document.body.appendChild(e);if(NREUMQ.a)NREUMQ.a();};NREUMQ.a=window.onload;window.onload=NREUMQ.f;};NREUMQ.push(["nrfj","beacon-1.newrelic.com","72d7dcce33","1388850","ZV1TZ0FTVkFVWkwKXlwXZEFaHRIdXVdcBkkcSFlD",0,749,new Date().getTime(),"","","","",""]);</script></body>
</html>
